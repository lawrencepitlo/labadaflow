/**
 * LabadaFlow seed script.
 *
 * Usage:
 *   pnpm seed
 *
 * Requires NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in .env.local.
 * Creates services and a few walk-in customers. Idempotent-ish: skips services
 * that already exist by name and customers that already exist by phone/email.
 */
import { createClient } from '@supabase/supabase-js'
import { readFileSync, existsSync } from 'node:fs'
import { resolve } from 'node:path'

function loadEnv() {
  const path = resolve(process.cwd(), '.env.local')
  if (!existsSync(path)) return
  for (const line of readFileSync(path, 'utf8').split('\n')) {
    const match = line.match(/^\s*([^#=]+)=(.*)\s*$/)
    if (match && !process.env[match[1]]) {
      process.env[match[1]] = match[2]
    }
  }
}

async function main() {
  loadEnv()

  const url = process.env.NEXT_PUBLIC_SUPABASE_URL
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY
  if (!url || !serviceKey) {
    console.error('Missing NEXT_PUBLIC_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY in .env.local')
    process.exit(1)
  }

  const supabase = createClient(url, serviceKey)

  const services = [
    { name: 'Wash & Fold', description: 'Standard wash and fold', pricing_unit: 'PER_KG', unit_price_cents: 8000, sort_order: 1 },
    { name: 'Wash & Iron', description: 'Wash, dry, and press', pricing_unit: 'PER_KG', unit_price_cents: 12000, sort_order: 2 },
    { name: 'Dry Clean', description: 'Dry cleaning per piece', pricing_unit: 'PER_PIECE', unit_price_cents: 15000, sort_order: 3 },
    { name: 'Iron Only', description: 'Pressing only', pricing_unit: 'PER_PIECE', unit_price_cents: 3000, sort_order: 4 },
  ]

  for (const svc of services) {
    const { data: existing } = await supabase.from('services').select('id').eq('name', svc.name).maybeSingle()
    if (!existing) {
      const { error } = await supabase.from('services').insert(svc)
      if (error) console.error(`Service ${svc.name}:`, error.message)
      else console.log(`+ service ${svc.name}`)
    } else {
      console.log(`= service ${svc.name} (exists)`)
    }
  }

  const customers: { full_name: string; phone: string | null; email: string | null; address: string | null }[] = [
    { full_name: 'Walk-in Customer', phone: null, email: null, address: null },
    { full_name: 'Juan Dela Cruz', phone: '09171234567', email: 'juan@example.com', address: 'Quezon City' },
    { full_name: 'Maria Santos', phone: '09179876543', email: 'maria@example.com', address: 'Manila' },
  ]

  for (const c of customers) {
    const query = c.phone
      ? supabase.from('customers').select('id').eq('phone', c.phone).maybeSingle()
      : supabase.from('customers').select('id').eq('full_name', c.full_name).maybeSingle()
    const { data: existing } = await query
    if (!existing) {
      const { error } = await supabase.from('customers').insert(c)
      if (error) console.error(`Customer ${c.full_name}:`, error.message)
      else console.log(`+ customer ${c.full_name}`)
    } else {
      console.log(`= customer ${c.full_name} (exists)`)
    }
  }

  console.log('Seed complete.')
}

main().catch(err => {
  console.error(err)
  process.exit(1)
})
