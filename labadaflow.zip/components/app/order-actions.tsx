'use client'

import { useState, useTransition } from 'react'
import { useRouter } from 'next/navigation'
import {
  advanceOrderStatus,
  cancelOrder,
  completeOrder,
} from '@/lib/actions/orders'
import { getNextStatus, getPreviousStatus, type OrderStatus } from '@/lib/order-machine'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'

interface OrderActionsProps {
  orderId: string
  status: OrderStatus
}

export function OrderActions({ orderId, status }: OrderActionsProps) {
  const router = useRouter()
  const [isPending, startTransition] = useTransition()
  const [error, setError] = useState<string | null>(null)
  const [note, setNote] = useState('')
  const [cancelReason, setCancelReason] = useState('')

  const next = getNextStatus(status)
  const previous = getPreviousStatus(status)
  const isTerminal = status === 'COMPLETED' || status === 'CANCELLED'

  function run(action: () => Promise<{ error?: string; success?: boolean }>) {
    setError(null)
    startTransition(async () => {
      const result = await action()
      if (result?.error) {
        setError(result.error)
      } else {
        setNote('')
        setCancelReason('')
        router.refresh()
      }
    })
  }

  if (isTerminal) {
    return <p className="text-sm text-muted-foreground">This order is {status.toLowerCase()} and cannot be changed.</p>
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">
        {next && (
          <Button
            disabled={isPending}
            onClick={() => run(() => advanceOrderStatus({ order_id: orderId, to_status: next }))}
          >
            Advance to {next}
          </Button>
        )}
        {status === 'READY' && (
          <Button
            disabled={isPending}
            onClick={() => run(() => completeOrder({ order_id: orderId }))}
          >
            Complete &amp; Mark Paid
          </Button>
        )}
      </div>

      {previous && (
        <div className="space-y-2">
          <Textarea
            placeholder={`Note required to move back to ${previous}`}
            value={note}
            onChange={e => setNote(e.target.value)}
            aria-label="Backward transition note"
          />
          <Button
            variant="outline"
            disabled={isPending || !note.trim()}
            onClick={() => run(() => advanceOrderStatus({ order_id: orderId, to_status: previous, note }))}
          >
            Move back to {previous}
          </Button>
        </div>
      )}

      <div className="space-y-2">
        <Textarea
          placeholder="Cancellation reason"
          value={cancelReason}
          onChange={e => setCancelReason(e.target.value)}
          aria-label="Cancellation reason"
        />
        <AlertDialog>
          <AlertDialogTrigger render={<Button variant="destructive" disabled={isPending || !cancelReason.trim()} />}>
            Cancel Order
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Cancel this order?</AlertDialogTitle>
              <AlertDialogDescription>
                This will mark the order as cancelled. Terminal orders cannot transition.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Back</AlertDialogCancel>
              <AlertDialogAction
                onClick={() => run(() => cancelOrder({ order_id: orderId, cancel_reason: cancelReason }))}
              >
                Confirm Cancel
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>

      {error && <p className="text-sm text-destructive" role="alert">{error}</p>}
    </div>
  )
}
