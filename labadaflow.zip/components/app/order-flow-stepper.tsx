'use client'

import { cn } from 'cn'
import { ORDER_STATUS_FLOW, STATUS_CONFIG, type OrderStatus } from '@/lib/order-machine'
import { Check } from 'lucide-react'

interface OrderFlowStepperProps {
  currentStatus: OrderStatus
  className?: string
}

const WORKFLOW_STEPS = ORDER_STATUS_FLOW.filter(s => s !== 'COMPLETED')

export function OrderFlowStepper({ currentStatus, className }: OrderFlowStepperProps) {
  const isCancelled = currentStatus === 'CANCELLED'
  const isCompleted = currentStatus === 'COMPLETED'
  const currentIndex = WORKFLOW_STEPS.indexOf(currentStatus as (typeof WORKFLOW_STEPS)[number])

  return (
    <div className={cn('w-full', className)}>
      {/* Desktop horizontal stepper */}
      <div className="hidden md:flex items-center justify-between" role="list" aria-label="Order progress">
        {WORKFLOW_STEPS.map((status, index) => {
          const config = STATUS_CONFIG[status]
          const isActive = status === currentStatus
          const isPast = isCompleted || (!isCancelled && currentIndex > index)
          const isFuture = !isCancelled && !isCompleted && currentIndex < index

          return (
            <div key={status} className="flex items-center flex-1 last:flex-none" role="listitem">
              <div className="flex flex-col items-center">
                <div
                  className={cn(
                    'flex items-center justify-center w-10 h-10 rounded-full border-2 transition-all duration-300',
                    isActive && !isCancelled && 'border-primary bg-primary text-primary-foreground scale-110 shadow-md',
                    isPast && 'border-emerald-500 bg-emerald-500 text-white',
                    isFuture && 'border-muted-foreground/30 bg-background text-muted-foreground/50',
                    isCancelled && 'border-red-300 bg-red-50 text-red-400 dark:border-red-800 dark:bg-red-950 dark:text-red-500'
                  )}
                  aria-current={isActive ? 'step' : undefined}
                >
                  {isPast ? (
                    <Check className="w-5 h-5" aria-hidden="true" />
                  ) : (
                    <span className="text-sm font-semibold">{index + 1}</span>
                  )}
                </div>
                <span
                  className={cn(
                    'mt-2 text-xs font-medium text-center',
                    isActive && !isCancelled && 'text-foreground font-semibold',
                    isPast && 'text-emerald-600 dark:text-emerald-400',
                    isFuture && 'text-muted-foreground/50',
                    isCancelled && 'text-red-400 dark:text-red-500'
                  )}
                >
                  {config.label}
                </span>
              </div>
              {index < WORKFLOW_STEPS.length - 1 && (
                <div
                  className={cn(
                    'flex-1 h-0.5 mx-2 mt-[-1.25rem] transition-all duration-300',
                    isPast ? 'bg-emerald-500' : 'bg-muted-foreground/20',
                    isCancelled && 'bg-red-200 dark:bg-red-900'
                  )}
                  aria-hidden="true"
                />
              )}
            </div>
          )
        })}
      </div>

      {/* Mobile vertical stepper */}
      <div className="md:hidden space-y-3" role="list" aria-label="Order progress">
        {WORKFLOW_STEPS.map((status, index) => {
          const config = STATUS_CONFIG[status]
          const isActive = status === currentStatus
          const isPast = isCompleted || (!isCancelled && currentIndex > index)

          return (
            <div key={status} className="flex items-center gap-3" role="listitem">
              <div
                className={cn(
                  'flex items-center justify-center w-8 h-8 rounded-full border-2 shrink-0',
                  isActive && !isCancelled && 'border-primary bg-primary text-primary-foreground',
                  isPast && 'border-emerald-500 bg-emerald-500 text-white',
                  !isActive && !isPast && 'border-muted-foreground/30 text-muted-foreground/50',
                  isCancelled && 'border-red-300 bg-red-50 text-red-400 dark:border-red-800 dark:bg-red-950'
                )}
                aria-current={isActive ? 'step' : undefined}
              >
                {isPast ? (
                  <Check className="w-4 h-4" aria-hidden="true" />
                ) : (
                  <span className="text-xs font-semibold">{index + 1}</span>
                )}
              </div>
              <span
                className={cn(
                  'text-sm',
                  isActive && !isCancelled && 'font-semibold text-foreground',
                  isPast && 'text-emerald-600 dark:text-emerald-400',
                  !isActive && !isPast && 'text-muted-foreground/50'
                )}
              >
                {config.label}
              </span>
            </div>
          )
        })}
      </div>

      {/* Terminal status indicators */}
      {isCompleted && (
        <div className="mt-4 flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-semibold">
          <Check className="w-5 h-5" aria-hidden="true" />
          <span>Order Completed & Paid</span>
        </div>
      )}
      {isCancelled && (
        <div className="mt-4 flex items-center gap-2 text-red-600 dark:text-red-400 font-semibold">
          <span className="w-5 h-5 flex items-center justify-center">✕</span>
          <span>Order Cancelled</span>
        </div>
      )}
    </div>
  )
}
