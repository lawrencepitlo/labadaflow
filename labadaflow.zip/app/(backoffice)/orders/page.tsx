import Link from 'next/link'
import { getOrders } from '@/lib/data/orders'
import { PageHeader } from '@/components/app/page-header'
import { StatusBadge } from '@/components/app/status-badge'
import { EmptyState } from '@/components/app/empty-state'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { formatMoney } from '@/lib/money'
import { formatDateTime } from '@/lib/time'
import { Plus, ClipboardList } from 'lucide-react'
import { OrdersFilter } from './orders-filter'

export default async function OrdersPage({
  searchParams,
}: {
  searchParams: Promise<{ search?: string; status?: string; page?: string }>
}) {
  const params = await searchParams
  const result = await getOrders({
    search: params.search,
    status: params.status,
    page: params.page ? Number(params.page) : 1,
  })

  if (!result) {
    return <EmptyState title="Access Denied" description="You do not have permission to view orders." />
  }

  const { orders, total, page, pageSize } = result
  const totalPages = Math.ceil(total / pageSize)

  return (
    <>
      <PageHeader title="Orders" description={`${total} total orders`}>
        <Button render={<Link href="/orders/new" />}>
            <Plus className="w-4 h-4 mr-2" />
            New Order
          </Button>
      </PageHeader>

      {/* Filters */}
      <OrdersFilter
        currentSearch={params.search}
        currentStatus={params.status}
      />

      {/* Orders Table */}
      {orders.length === 0 ? (
        <EmptyState
          icon={ClipboardList}
          title="No orders found"
          description={params.search || params.status ? 'Try adjusting your filters.' : 'Create your first order to get started.'}
          actionLabel={!params.search && !params.status ? 'Create Order' : undefined}
          actionHref={!params.search && !params.status ? '/orders/new' : undefined}
        />
      ) : (
        <>
          {/* Desktop Table */}
          <Card className="hidden md:block">
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Order #</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Total</TableHead>
                    <TableHead>Received</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {orders.map(order => (
                    <TableRow key={order.id} className="cursor-pointer">
                      <TableCell>
                        <Link href={`/orders/${order.id}`} className="font-medium text-primary hover:underline">
                          {order.order_number}
                        </Link>
                      </TableCell>
                      <TableCell>
                        <div>
                          <p className="font-medium">{order.customer.full_name}</p>
                          {order.customer.phone && (
                            <p className="text-xs text-muted-foreground">{order.customer.phone}</p>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <StatusBadge status={order.status} size="sm" />
                      </TableCell>
                      <TableCell className="font-medium">{formatMoney(order.total_cents)}</TableCell>
                      <TableCell className="text-muted-foreground text-sm">{formatDateTime(order.received_at)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          {/* Mobile Cards */}
          <div className="md:hidden space-y-3">
            {orders.map(order => (
              <Link key={order.id} href={`/orders/${order.id}`}>
                <Card className="hover:bg-accent/50 transition-colors">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-semibold text-primary">{order.order_number}</span>
                      <StatusBadge status={order.status} size="sm" />
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span>{order.customer.full_name}</span>
                      <span className="font-medium">{formatMoney(order.total_cents)}</span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">{formatDateTime(order.received_at)}</p>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-2 mt-6">
              {page > 1 && (
                <Button variant="outline" size="sm" render={<Link href={`/orders?page=${page - 1}${params.status ? `&status=${params.status}` : ''}${params.search ? `&search=${params.search}` : ''}`} />}>
                    Previous
                  </Button>
              )}
              <span className="text-sm text-muted-foreground">
                Page {page} of {totalPages}
              </span>
              {page < totalPages && (
                <Button variant="outline" size="sm" render={<Link href={`/orders?page=${page + 1}${params.status ? `&status=${params.status}` : ''}${params.search ? `&search=${params.search}` : ''}`} />}>
                    Next
                  </Button>
              )}
            </div>
          )}
        </>
      )}
    </>
  )
}
