'use client'

import { useRouter } from 'next/navigation'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Search } from 'lucide-react'
import { useCallback, useState, useTransition } from 'react'

const STATUS_OPTIONS = [
  { value: 'ALL', label: 'All Statuses' },
  { value: 'RECEIVED', label: 'Received' },
  { value: 'WASHING', label: 'Washing' },
  { value: 'DRYING', label: 'Drying' },
  { value: 'FOLDING', label: 'Folding' },
  { value: 'READY', label: 'Ready' },
  { value: 'COMPLETED', label: 'Completed' },
  { value: 'CANCELLED', label: 'Cancelled' },
]

interface OrdersFilterProps {
  currentSearch?: string
  currentStatus?: string
}

export function OrdersFilter({ currentSearch, currentStatus }: OrdersFilterProps) {
  const router = useRouter()
  const [search, setSearch] = useState(currentSearch ?? '')
  const [, startTransition] = useTransition()

  const updateFilters = useCallback(
    (newSearch?: string, newStatus?: string) => {
      const params = new URLSearchParams()
      const s = newSearch ?? search
      const st = newStatus ?? currentStatus

      if (s) params.set('search', s)
      if (st && st !== 'ALL') params.set('status', st)

      startTransition(() => {
        router.push(`/orders?${params.toString()}`)
      })
    },
    [router, search, currentStatus]
  )

  return (
    <div className="flex flex-col sm:flex-row gap-3 mb-6">
      <div className="relative flex-1">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search orders..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          onKeyDown={e => {
            if (e.key === 'Enter') updateFilters(search)
          }}
          className="pl-9"
        />
      </div>
      <Select
        value={currentStatus ?? 'ALL'}
        onValueChange={value => updateFilters(undefined, value ?? undefined)}
      >
        <SelectTrigger className="w-full sm:w-[180px]">
          <SelectValue placeholder="Filter by status" />
        </SelectTrigger>
        <SelectContent>
          {STATUS_OPTIONS.map(opt => (
            <SelectItem key={opt.value} value={opt.value}>
              {opt.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  )
}
