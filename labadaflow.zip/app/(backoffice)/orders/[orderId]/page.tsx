import Link from 'next/link'
import { getOrderById } from '@/lib/data/orders'
import { getActiveServices } from '@/lib/data/services'
import { PageHeader } from '@/components/app/page-header'
import { StatusBadge } from '@/components/app/status-badge'
import { EmptyState } from '@/components/app/empty-state'
import { OrderFlowStepper } from '@/components/app/order-flow-stepper'
import { OrderActions } from '@/components/app/order-actions'
import { OrderItemsEditor } from '@/components/app/order-items-editor'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { formatMoney } from '@/lib/money'
import { formatDateTime } from '@/lib/time'
import type { OrderStatus } from '@/lib/order-machine'

export default async function OrderDetailPage({
  params,
}: {
  params: Promise<{ orderId: string }>
}) {
  const { orderId } = await params
  const order = await getOrderById(orderId)

  if (!order) {
    return <EmptyState title="Order not found" description="This order does not exist or you do not have access." />
  }

  const services = order.status === 'RECEIVED' ? await getActiveServices() : []

  return (
    <>
      <PageHeader title={`Order ${order.order_number}`} description={`Created ${formatDateTime(order.created_at)}`}>
        <Button variant="outline" render={<Link href={`/orders/${order.id}/slip`} />}>Print Slip</Button>
      </PageHeader>

      <div className="mb-8">
        <OrderFlowStepper currentStatus={order.status} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Items</CardTitle>
            </CardHeader>
            <CardContent>
              {order.status === 'RECEIVED' ? (
                <OrderItemsEditor orderId={order.id} items={order.items} services={services} />
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Service</TableHead>
                      <TableHead>Unit</TableHead>
                      <TableHead>Qty</TableHead>
                      <TableHead className="text-right">Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {order.items.map(item => (
                      <TableRow key={item.id}>
                        <TableCell>{item.service_name}</TableCell>
                        <TableCell>{formatMoney(item.unit_price_cents)} / {item.pricing_unit === 'PER_KG' ? 'kg' : 'pc'}</TableCell>
                        <TableCell>{item.quantity}</TableCell>
                        <TableCell className="text-right">{formatMoney(item.line_total_cents)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
              <div className="flex justify-end mt-4 text-lg font-bold">
                Total: {formatMoney(order.total_cents)}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Status History</CardTitle>
            </CardHeader>
            <CardContent>
              <ol className="space-y-3">
                {order.events.map(event => (
                  <li key={event.id} className="flex justify-between gap-4 text-sm border-l-2 border-muted pl-4">
                    <div>
                      <p className="font-medium">
                        {event.from_status ? `${event.from_status} → ` : ''}{event.to_status}
                      </p>
                      <p className="text-muted-foreground">by {event.actor_name}</p>
                      {event.note && <p className="text-muted-foreground italic">“{event.note}”</p>}
                    </div>
                    <time className="text-muted-foreground whitespace-nowrap">{formatDateTime(event.created_at)}</time>
                  </li>
                ))}
              </ol>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-muted-foreground">Status</span><StatusBadge status={order.status} size="sm" /></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Customer</span><span>{order.customer.full_name}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Phone</span><span>{order.customer.phone ?? '—'}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Source</span><span>{order.source}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Assigned to</span><span>{order.assigned_staff?.full_name ?? '—'}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Due</span><span>{order.due_at ? formatDateTime(order.due_at) : '—'}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Paid at</span><span>{order.paid_at ? formatDateTime(order.paid_at) : '—'}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Tracking</span><code className="text-xs">{order.tracking_code}</code></div>
              {order.notes && <p className="pt-2 text-muted-foreground">Notes: {order.notes}</p>}
              {order.cancel_reason && <p className="pt-2 text-destructive">Cancel reason: {order.cancel_reason}</p>}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <OrderActions orderId={order.id} status={order.status as OrderStatus} />
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  )
}
