import { getReports } from '@/lib/data/reports'
import { PageHeader } from '@/components/app/page-header'
import { EmptyState } from '@/components/app/empty-state'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { formatMoney } from '@/lib/money'

export default async function ReportsPage() {
  const report = await getReports()

  if (!report) {
    return <EmptyState title="Access Denied" description="You do not have permission to view reports." />
  }

  const cards = [
    { title: 'Orders today', value: report.ordersToday.toString() },
    { title: 'Orders this week', value: report.ordersThisWeek.toString() },
    { title: 'Revenue today', value: formatMoney(report.revenueToday) },
    { title: 'Revenue this week', value: formatMoney(report.revenueThisWeek) },
    { title: 'Total revenue', value: formatMoney(report.revenueTotal) },
  ]

  return (
    <>
      <PageHeader title="Reports" description="Operational summary" />

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-4 mb-8">
        {cards.map(c => (
          <Card key={c.title}>
            <CardContent className="pt-6">
              <p className="text-sm font-medium text-muted-foreground">{c.title}</p>
              <p className="text-2xl font-bold mt-1">{c.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Revenue by Service</CardTitle>
          </CardHeader>
          <CardContent>
            {report.ordersByService.length === 0 ? (
              <p className="text-sm text-muted-foreground">No service data yet.</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Service</TableHead>
                    <TableHead>Items sold</TableHead>
                    <TableHead className="text-right">Revenue</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {report.ordersByService.map(s => (
                    <TableRow key={s.service_name}>
                      <TableCell>{s.service_name}</TableCell>
                      <TableCell>{s.count}</TableCell>
                      <TableCell className="text-right">{formatMoney(s.revenue_cents)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Orders by Status</CardTitle>
          </CardHeader>
          <CardContent>
            {Object.keys(report.statusBreakdown).length === 0 ? (
              <p className="text-sm text-muted-foreground">No orders yet.</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Count</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {Object.entries(report.statusBreakdown).map(([status, count]) => (
                    <TableRow key={status}>
                      <TableCell>{status}</TableCell>
                      <TableCell className="text-right">{count}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </>
  )
}
