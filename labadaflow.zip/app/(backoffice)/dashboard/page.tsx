import Link from 'next/link'
import { getDashboardStats } from '@/lib/data/orders'
import { PageHeader } from '@/components/app/page-header'
import { StatusBadge } from '@/components/app/status-badge'
import { EmptyState } from '@/components/app/empty-state'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { formatMoney } from '@/lib/money'
import { formatRelativeTime } from '@/lib/time'
import {
  ClipboardList,
  Users,
  TrendingUp,
  Activity,
  ArrowRight,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import type { OrderStatus } from '@/lib/order-machine'

export default async function DashboardPage() {
  const stats = await getDashboardStats()

  if (!stats) {
    return <EmptyState title="Access Denied" description="You do not have permission to view this page." />
  }

  const statCards = [
    {
      title: 'Total Orders',
      value: stats.totalOrders.toString(),
      icon: ClipboardList,
      color: 'text-blue-600 dark:text-blue-400',
      bg: 'bg-blue-100 dark:bg-blue-950',
    },
    {
      title: 'Active Orders',
      value: stats.activeOrders.toString(),
      icon: Activity,
      color: 'text-amber-600 dark:text-amber-400',
      bg: 'bg-amber-100 dark:bg-amber-950',
    },
    {
      title: "Today's Revenue",
      value: formatMoney(stats.todayRevenue),
      icon: TrendingUp,
      color: 'text-emerald-600 dark:text-emerald-400',
      bg: 'bg-emerald-100 dark:bg-emerald-950',
    },
    {
      title: 'Customers',
      value: stats.customerCount.toString(),
      icon: Users,
      color: 'text-purple-600 dark:text-purple-400',
      bg: 'bg-purple-100 dark:bg-purple-950',
    },
  ]

  return (
    <>
      <PageHeader title="Dashboard" description="Overview of your laundry operations">
        <Button render={<Link href="/orders/new" />}>New Order</Button>
      </PageHeader>

      {/* Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-8">
        {statCards.map(card => (
          <Card key={card.title}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">{card.title}</p>
                  <p className="text-2xl font-bold mt-1">{card.value}</p>
                </div>
                <div className={`p-3 rounded-full ${card.bg}`}>
                  <card.icon className={`w-5 h-5 ${card.color}`} aria-hidden="true" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Recent Orders */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-lg">Recent Orders</CardTitle>
          <Button variant="ghost" size="sm" render={<Link href="/orders" className="flex items-center gap-1" />}>
              View all <ArrowRight className="w-4 h-4" />
            </Button>
        </CardHeader>
        <CardContent>
          {stats.recentOrders.length === 0 ? (
            <EmptyState
              title="No orders yet"
              description="Create your first order to get started."
              actionLabel="Create Order"
              actionHref="/orders/new"
            />
          ) : (
            <div className="space-y-3">
              {stats.recentOrders.map((order) => (
                <Link
                  key={order.id}
                  href={`/orders/${order.id}`}
                  className="flex items-center justify-between p-3 rounded-lg hover:bg-accent transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div>
                      <p className="font-medium text-sm">{order.order_number}</p>
                      <p className="text-xs text-muted-foreground">
                        {(() => { const c = Array.isArray(order.customer) ? order.customer[0] : order.customer; return c?.full_name })()}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-medium hidden sm:inline">
                      {formatMoney(order.total_cents)}
                    </span>
                    <StatusBadge status={order.status as OrderStatus} size="sm" />
                    <span className="text-xs text-muted-foreground hidden md:inline">
                      {formatRelativeTime(order.created_at)}
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </>
  )
}
