import Link from 'next/link'
import { getCustomerById } from '@/lib/data/customers'
import { getOrdersByCustomerForStaff } from '@/lib/data/orders'
import { getActor } from '@/lib/auth'
import { PageHeader } from '@/components/app/page-header'
import { EmptyState } from '@/components/app/empty-state'
import { StatusBadge } from '@/components/app/status-badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { formatMoney } from '@/lib/money'
import { formatDateTime } from '@/lib/time'
import type { OrderStatus } from '@/lib/order-machine'
import { EditCustomerForm } from './edit-customer-form'
import { ArchiveButtons } from './archive-buttons'

export default async function CustomerDetailPage({
  params,
}: {
  params: Promise<{ customerId: string }>
}) {
  const { customerId } = await params
  const [customer, actor, orders] = await Promise.all([
    getCustomerById(customerId),
    getActor(),
    getOrdersByCustomerForStaff(customerId),
  ])

  if (!customer) {
    return <EmptyState title="Customer not found" description="This customer does not exist or you do not have access." />
  }

  return (
    <>
      <PageHeader title={customer.full_name} description={customer.archived_at ? 'Archived customer' : 'Customer details'} />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Info</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-muted-foreground">Phone</span><span>{customer.phone ?? '—'}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Email</span><span>{customer.email ?? '—'}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Address</span><span>{customer.address ?? '—'}</span></div>
              {customer.notes && <p className="pt-2 text-muted-foreground">Notes: {customer.notes}</p>}
            </CardContent>
          </Card>

          {actor?.role === 'ADMIN' && (
            <ArchiveButtons customerId={customer.id} archived={!!customer.archived_at} />
          )}
        </div>

        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Edit Customer</CardTitle>
            </CardHeader>
            <CardContent>
              <EditCustomerForm customer={customer} />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Order History</CardTitle>
            </CardHeader>
            <CardContent>
              {orders.length === 0 ? (
                <p className="text-sm text-muted-foreground">No orders yet.</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Order #</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Total</TableHead>
                      <TableHead>Received</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {orders.map((o: { id: string; order_number: string; status: string; total_cents: number; received_at: string }) => (
                      <TableRow key={o.id}>
                        <TableCell>
                          <Link href={`/orders/${o.id}`} className="font-medium text-primary hover:underline">
                            {o.order_number}
                          </Link>
                        </TableCell>
                        <TableCell><StatusBadge status={o.status as OrderStatus} size="sm" /></TableCell>
                        <TableCell>{formatMoney(o.total_cents)}</TableCell>
                        <TableCell className="text-muted-foreground text-sm">{formatDateTime(o.received_at)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  )
}
