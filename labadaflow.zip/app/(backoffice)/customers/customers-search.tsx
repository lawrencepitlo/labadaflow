'use client'

import { useRouter } from 'next/navigation'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Search } from 'lucide-react'
import { useState } from 'react'

export function CustomersSearch({ currentSearch }: { currentSearch?: string }) {
  const router = useRouter()
  const [search, setSearch] = useState(currentSearch ?? '')

  return (
    <div className="flex gap-2 mb-6 max-w-md">
      <div className="relative flex-1">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search customers..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          onKeyDown={e => {
            if (e.key === 'Enter') {
              router.push(search ? `/customers?search=${encodeURIComponent(search)}` : '/customers')
            }
          }}
          className="pl-9"
          aria-label="Search customers"
        />
      </div>
      <Button onClick={() => router.push(search ? `/customers?search=${encodeURIComponent(search)}` : '/customers')}>
        Search
      </Button>
    </div>
  )
}
