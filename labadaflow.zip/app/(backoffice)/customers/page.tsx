import Link from 'next/link'
import { getCustomers } from '@/lib/data/customers'
import { PageHeader } from '@/components/app/page-header'
import { EmptyState } from '@/components/app/empty-state'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { formatDate } from '@/lib/time'
import { Plus } from 'lucide-react'
import { NewCustomerForm } from './new-customer-form'
import { CustomersSearch } from './customers-search'

export default async function CustomersPage({
  searchParams,
}: {
  searchParams: Promise<{ search?: string; page?: string }>
}) {
  const params = await searchParams
  const result = await getCustomers({
    search: params.search,
    page: params.page ? Number(params.page) : 1,
  })

  if (!result) {
    return <EmptyState title="Access Denied" description="You do not have permission to view customers." />
  }

  const { customers, total, page, pageSize } = result
  const totalPages = Math.ceil(total / pageSize)

  return (
    <>
      <PageHeader title="Customers" description={`${total} total customers`}>
        <Button render={<Link href="#new-customer" />}>
            <Plus className="w-4 h-4 mr-2" /> New Customer
          </Button>
      </PageHeader>

      <CustomersSearch currentSearch={params.search} />

      {customers.length === 0 ? (
        <EmptyState
          title="No customers found"
          description={params.search ? 'Try a different search.' : 'Create your first customer to get started.'}
        />
      ) : (
        <>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Phone</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Orders</TableHead>
                    <TableHead>Created</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {customers.map(c => (
                    <TableRow key={c.id}>
                      <TableCell>
                        <Link href={`/customers/${c.id}`} className="font-medium text-primary hover:underline">
                          {c.full_name}
                        </Link>
                      </TableCell>
                      <TableCell>{c.phone ?? '—'}</TableCell>
                      <TableCell>{c.email ?? '—'}</TableCell>
                      <TableCell>{c.order_count}</TableCell>
                      <TableCell className="text-muted-foreground text-sm">{formatDate(c.created_at)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-2 mt-6">
              {page > 1 && (
                <Button variant="outline" size="sm" render={<Link href={`/customers?page=${page - 1}${params.search ? `&search=${params.search}` : ''}`} />}>Previous</Button>
              )}
              <span className="text-sm text-muted-foreground">Page {page} of {totalPages}</span>
              {page < totalPages && (
                <Button variant="outline" size="sm" render={<Link href={`/customers?page=${page + 1}${params.search ? `&search=${params.search}` : ''}`} />}>Next</Button>
              )}
            </div>
          )}
        </>
      )}

      <div id="new-customer" className="mt-10">
        <h2 className="text-lg font-semibold mb-4">New Customer</h2>
        <NewCustomerForm />
      </div>
    </>
  )
}
