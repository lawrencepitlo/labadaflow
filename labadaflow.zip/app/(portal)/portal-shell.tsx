'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from 'cn'
import { UserButton } from '@clerk/nextjs'
import { Droplets, ClipboardList, User } from 'lucide-react'

const NAV = [
  { href: '/portal/orders', label: 'My Orders', icon: ClipboardList },
  { href: '/portal/profile', label: 'Profile', icon: User },
]

export function PortalShell({
  customerName,
  children,
}: {
  customerName: string
  children: React.ReactNode
}) {
  const pathname = usePathname()

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="flex items-center justify-between border-b px-4 sm:px-6 py-3 bg-card">
        <div className="flex items-center gap-2">
          <Droplets className="w-6 h-6 text-primary" aria-hidden="true" />
          <span className="font-bold">LabadaFlow</span>
        </div>
        <nav className="flex items-center gap-1">
          {NAV.map(item => {
            const active = pathname.startsWith(item.href)
            return (
              <Link
                key={item.href}
                href={item.href}
                aria-current={active ? 'page' : undefined}
                className={cn(
                  'flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-colors',
                  active ? 'bg-primary/10 text-primary' : 'text-muted-foreground hover:bg-accent'
                )}
              >
                <item.icon className="w-4 h-4" aria-hidden="true" />
                <span className="hidden sm:inline">{item.label}</span>
              </Link>
            )
          })}
        </nav>
        <div className="flex items-center gap-3">
          <span className="hidden md:inline text-sm text-muted-foreground">{customerName}</span>
          <UserButton />
        </div>
      </header>
      <main className="flex-1">
        <div className="container max-w-5xl mx-auto px-4 py-6">{children}</div>
      </main>
    </div>
  )
}
