import { getOrderById } from '@/lib/data/orders'
import { PageHeader } from '@/components/app/page-header'
import { EmptyState } from '@/components/app/empty-state'
import { StatusBadge } from '@/components/app/status-badge'
import { OrderFlowStepper } from '@/components/app/order-flow-stepper'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { formatMoney } from '@/lib/money'
import { formatDateTime } from '@/lib/time'

export default async function PortalOrderDetailPage({
  params,
}: {
  params: Promise<{ orderId: string }>
}) {
  const { orderId } = await params
  const order = await getOrderById(orderId)

  if (!order) {
    return <EmptyState title="Order not found" description="This order does not exist or does not belong to you." />
  }

  return (
    <>
      <PageHeader title={`Order ${order.order_number}`} description={`Received ${formatDateTime(order.received_at)}`}>
        <StatusBadge status={order.status} />
      </PageHeader>

      <div className="mb-8">
        <OrderFlowStepper currentStatus={order.status} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Items</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Service</TableHead>
                    <TableHead>Unit</TableHead>
                    <TableHead>Qty</TableHead>
                    <TableHead className="text-right">Total</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {order.items.map(item => (
                    <TableRow key={item.id}>
                      <TableCell>{item.service_name}</TableCell>
                      <TableCell>{formatMoney(item.unit_price_cents)} / {item.pricing_unit === 'PER_KG' ? 'kg' : 'pc'}</TableCell>
                      <TableCell>{item.quantity}</TableCell>
                      <TableCell className="text-right">{formatMoney(item.line_total_cents)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              <div className="flex justify-end mt-4 text-lg font-bold">Total: {formatMoney(order.total_cents)}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Status History</CardTitle>
            </CardHeader>
            <CardContent>
              <ol className="space-y-3">
                {order.events.map(event => (
                  <li key={event.id} className="flex justify-between gap-4 text-sm border-l-2 border-muted pl-4">
                    <div>
                      <p className="font-medium">{event.from_status ? `${event.from_status} → ` : ''}{event.to_status}</p>
                      {event.note && <p className="text-muted-foreground italic">“{event.note}”</p>}
                    </div>
                    <time className="text-muted-foreground whitespace-nowrap">{formatDateTime(event.created_at)}</time>
                  </li>
                ))}
              </ol>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <div className="flex justify-between"><span className="text-muted-foreground">Status</span><span>{order.status}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Received</span><span>{formatDateTime(order.received_at)}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Due</span><span>{order.due_at ? formatDateTime(order.due_at) : '—'}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Completed</span><span>{order.completed_at ? formatDateTime(order.completed_at) : '—'}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Tracking</span><code className="text-xs">{order.tracking_code}</code></div>
            {order.cancel_reason && <p className="pt-2 text-destructive">Cancel reason: {order.cancel_reason}</p>}
          </CardContent>
        </Card>
      </div>
    </>
  )
}
