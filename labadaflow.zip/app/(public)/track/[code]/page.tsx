import Link from 'next/link'
import { getOrderByTrackingCode } from '@/lib/data/orders'
import { STATUS_CONFIG, type OrderStatus } from '@/lib/order-machine'
import { StatusBadge } from '@/components/app/status-badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { formatDate } from '@/lib/time'
import { Droplets } from 'lucide-react'

export default async function TrackCodePage({
  params,
}: {
  params: Promise<{ code: string }>
}) {
  const { code } = await params
  const order = await getOrderByTrackingCode(code)

  return (
    <div className="flex flex-col min-h-screen">
      <header className="flex items-center gap-2 px-6 py-4 border-b">
        <Link href="/" className="flex items-center gap-2">
          <Droplets className="w-7 h-7 text-primary" aria-hidden="true" />
          <span className="font-bold text-lg tracking-tight">LabadaFlow</span>
        </Link>
      </header>
      <main className="flex-1 flex items-center justify-center px-4">
        <Card className="w-full max-w-md">
          <CardContent className="pt-8 pb-8">
            {!order ? (
              <>
                <h1 className="text-xl font-bold mb-2">Order not found</h1>
                <p className="text-sm text-muted-foreground mb-6">
                  We could not find an order with that tracking code. Please check the code and try again.
                </p>
                <Button render={<Link href="/track" />} variant="outline">Try again</Button>
              </>
            ) : (
              <>
                <p className="text-sm text-muted-foreground mb-1">Order {order.order_number}</p>
                <h1 className="text-2xl font-bold mb-4">
                  {STATUS_CONFIG[order.status as OrderStatus]?.label ?? order.status}
                </h1>
                <div className="mb-6">
                  <StatusBadge status={order.status as OrderStatus} size="lg" />
                </div>
                <dl className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <dt className="text-muted-foreground">Received</dt>
                    <dd>{formatDate(order.received_at)}</dd>
                  </div>
                  {order.due_at && (
                    <div className="flex justify-between">
                      <dt className="text-muted-foreground">Estimated ready</dt>
                      <dd>{formatDate(order.due_at)}</dd>
                    </div>
                  )}
                </dl>
                <div className="mt-6">
                  <Button render={<Link href="/track" />} variant="outline">Track another order</Button>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
