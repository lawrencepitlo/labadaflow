import Link from 'next/link'
import { redirect } from 'next/navigation'
import { Droplets, Search } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent } from '@/components/ui/card'

export default function TrackPage() {
  async function search(formData: FormData) {
    'use server'
    const code = String(formData.get('code') ?? '').trim()
    if (code) redirect(`/track/${encodeURIComponent(code)}`)
  }

  return (
    <div className="flex flex-col min-h-screen">
      <header className="flex items-center gap-2 px-6 py-4 border-b">
        <Link href="/" className="flex items-center gap-2">
          <Droplets className="w-7 h-7 text-primary" aria-hidden="true" />
          <span className="font-bold text-lg tracking-tight">LabadaFlow</span>
        </Link>
      </header>
      <main className="flex-1 flex items-center justify-center px-4">
        <Card className="w-full max-w-md">
          <CardContent className="pt-8 pb-8">
            <h1 className="text-2xl font-bold mb-2">Track your laundry</h1>
            <p className="text-sm text-muted-foreground mb-6">
              Enter the tracking code from your order slip.
            </p>
            <form action={search} className="flex gap-2">
              <Input name="code" placeholder="e.g. V1StGXR8_Z5jdHi6" required aria-label="Tracking code" />
              <Button type="submit">
                <Search className="w-4 h-4 mr-2" aria-hidden="true" />
                Track
              </Button>
            </form>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
