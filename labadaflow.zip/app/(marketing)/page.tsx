import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Droplets,
  ClipboardList,
  UsersRound,
  ShieldCheck,
  History,
  Tags,
  Package,
  WashingMachine,
  Wind,
  FoldVertical,
  ShoppingBag,
  CheckCircle2,
  ArrowRight,
} from 'lucide-react'

const STAGES = [
  { label: 'Received', icon: Package },
  { label: 'Washing', icon: WashingMachine },
  { label: 'Drying', icon: Wind },
  { label: 'Folding', icon: FoldVertical },
  { label: 'Ready', icon: ShoppingBag },
  { label: 'Completed', icon: CheckCircle2 },
]

const FEATURES = [
  { title: 'Real-time tracking', description: 'Customers follow their laundry with a simple unguessable tracking code.', icon: ClipboardList },
  { title: 'Team workflow', description: 'Staff advance every order through a defined, auditable workflow.', icon: UsersRound },
  { title: 'Customer portal', description: 'Customers see their own orders, history, and profile — nothing else.', icon: UsersRound },
  { title: 'Audit trail', description: 'Every status change records who, when, and why. Append-only history.', icon: ShieldCheck },
  { title: 'Order history', description: 'Search, filter, and review past orders by customer or service.', icon: History },
  { title: 'Service catalog', description: 'Admin-managed services with per-kilo and per-piece pricing.', icon: Tags },
]

export default function MarketingPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="flex items-center justify-between px-6 py-4 border-b">
        <div className="flex items-center gap-2">
          <Droplets className="w-7 h-7 text-primary" aria-hidden="true" />
          <span className="font-bold text-lg tracking-tight">LabadaFlow</span>
        </div>
        <nav className="flex items-center gap-3">
          <Button variant="ghost" render={<Link href="/track" />}>Track your laundry</Button>
          <Button render={<Link href="/login" />}>Sign In</Button>
        </nav>
      </header>

      {/* Hero */}
      <section className="flex flex-col items-center text-center px-6 py-24 bg-gradient-to-b from-primary/5 to-background">
        <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight max-w-3xl">
          Every load has a flow.
        </h1>
        <p className="mt-6 text-lg text-muted-foreground max-w-xl">
          LabadaFlow is a focused laundry management system that tracks every order
          from intake to release — clear for staff, transparent for customers.
        </p>
        <div className="mt-10 flex flex-col sm:flex-row gap-4">
          <Button size="lg" variant="outline" render={<a href="#flow" />}>See it in action</Button>
          <Button size="lg" render={<Link href="/login" />}>Sign In</Button>
        </div>
      </section>

      {/* Order flow story */}
      <section id="flow" className="px-6 py-20 max-w-5xl mx-auto w-full">
        <h2 className="text-3xl font-bold text-center mb-12">One defined flow, six stages</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {STAGES.map((stage, i) => (
            <div key={stage.label} className="flex flex-col items-center text-center">
              <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mb-3">
                <stage.icon className="w-6 h-6 text-primary" aria-hidden="true" />
              </div>
              <p className="font-medium text-sm">{stage.label}</p>
              {i < STAGES.length - 1 && (
                <ArrowRight className="hidden lg:block w-4 h-4 text-muted-foreground absolute translate-x-16" aria-hidden="true" />
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Features bento */}
      <section className="px-6 py-16 bg-muted/40">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Built for clarity</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {FEATURES.map(f => (
              <Card key={f.title}>
                <CardHeader>
                  <f.icon className="w-8 h-8 text-primary mb-2" aria-hidden="true" />
                  <CardTitle className="text-base">{f.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{f.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="px-6 py-20 max-w-4xl mx-auto w-full">
        <h2 className="text-3xl font-bold text-center mb-12">How it works</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          {[
            { n: '1', title: 'Staff receives', text: 'Log the order with services, quantity, and a tracking code.' },
            { n: '2', title: 'System tracks', text: 'Every transition is timestamped and attributed to a staff member.' },
            { n: '3', title: 'Customer picks up', text: 'Complete the order and record real-world payment in one step.' },
          ].map(s => (
            <div key={s.n}>
              <div className="w-10 h-10 rounded-full bg-primary text-primary-foreground font-bold flex items-center justify-center mx-auto mb-4">{s.n}</div>
              <h3 className="font-semibold mb-2">{s.title}</h3>
              <p className="text-sm text-muted-foreground">{s.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Value proposition */}
      <section className="px-6 py-16 bg-muted/40">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">Operational clarity, no complexity.</h2>
          <p className="text-muted-foreground">
            LabadaFlow stays focused: receive, process, release, repeat. No payment gateways,
            no bloated pipelines — just a reliable record of every load.
          </p>
        </div>
      </section>

      {/* CTA */}
      <section className="px-6 py-24 text-center">
        <h2 className="text-3xl font-bold mb-8">Ready to flow?</h2>
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <Button size="lg" render={<Link href="/login" />}>Sign In</Button>
          <Button size="lg" variant="outline" render={<Link href="/track" />}>Track your laundry →</Button>
        </div>
      </section>

      <footer className="border-t px-6 py-6 text-center text-sm text-muted-foreground">
        © {new Date().getFullYear()} LabadaFlow — Every load has a flow.
      </footer>
    </div>
  )
}
